package SNMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class notes 
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_notes_id,JL_subject_id,JL_course_id,JL_notes_write,JL_dateofclass;
	private JTextField JTF_notes_id,JTF_subject_id,JTF_course_id,JTF_notes_write,JTF_dateofclass;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert5,update5,view5,delete5;
	private List notesList;
	private Choice subjectId,courseId;
	public notes(JPanel pn,JFrame jframe,JMenuItem insert5,JMenuItem update5,JMenuItem view5,JMenuItem delete5)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert5=insert5;
		this.update5=update5;
		this.view5=view5;
		this.delete5=delete5;
		
		JL_notes_id=new JLabel("notes_Id:");
		JTF_notes_id=new JTextField(10);
		JL_subject_id=new JLabel("subject Id:");
		JTF_subject_id=new JTextField(10);
		JL_course_id=new JLabel("course id:");
		JTF_course_id=new JTextField(10);
		JL_notes_write=new JLabel("notes write:");
		JTF_notes_write=new JTextField(10);
		JL_dateofclass=new JLabel("dateofclass:");
		JTF_dateofclass=new JTextField(10);
                
        this.pn=pn;
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737086","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadsubject()
	{
		try
		{
			subjectId=new Choice();
			subjectId.removeAll();
			rs=stmt.executeQuery("select * from subject");
			while(rs.next()) 
			{
				subjectId.add(rs.getString("subject_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadcourse()
	{
		try
		{
			courseId=new Choice();
			courseId.removeAll();
			rs=stmt.executeQuery("select * from course");
			while(rs.next()) 
			{
				courseId.add(rs.getString("course_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadnotes()
	{
		try
		{
			notesList=new List();
			notesList.removeAll();
			rs=stmt.executeQuery("select * from notes");
			while(rs.next()) 
			{
				notesList.add(rs.getString("notes_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				loadsubject();
				loadcourse();
				loadnotes();
				
				JTF_notes_id.setText(null);
				//JTF_subject_id.setText(null);
				JTF_course_id.setText(null);
				JTF_notes_write.setText(null);
				JTF_dateofclass.setText(null);
				
				loadnotes();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_notes_id);
				pn1.add(JTF_notes_id);
				pn1.add(JL_subject_id);
				pn1.add(subjectId);
				pn1.add(JL_course_id);
				pn1.add(courseId);
				pn1.add(JL_notes_write);
				pn1.add(JTF_notes_write);
				pn1.add(JL_dateofclass);
				pn1.add(JTF_dateofclass);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				notesList=new List(10);
				loadnotes();
				pn2.add(notesList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO notes VALUES(" + JTF_notes_id.getText() + ","
							 +"'"+subjectId.getSelectedItem()+"',"+"'"+courseId.getSelectedItem()+"',"+"'"+JTF_notes_write.getText() +"'," +JTF_dateofclass.getText() +")";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadnotes();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_notes_id.setText(null);
				JTF_subject_id.setText(null);
				JTF_course_id.setText(null);
				JTF_notes_write.setText(null);
				JTF_dateofclass.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_notes_id);
				pn1.add(JTF_notes_id);
				pn1.add(JL_subject_id);
				pn1.add(JTF_subject_id);
				pn1.add(JL_course_id);
				pn1.add(JTF_course_id);
				pn1.add(JL_notes_write);
				pn1.add(JTF_notes_write);
				pn1.add(JL_dateofclass);
				pn1.add(JTF_dateofclass);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				notesList=new List(10);
				loadnotes();
				pn2.add(notesList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				

				notesList.addItemListener(new ItemListener()
				{
					public void itemStateChanged(ItemEvent ievt) 
					{
						try 
						{
							rs=stmt.executeQuery("select * from notes");					
							while (rs.next()) 
							{
								if (rs.getString("notes_id").equals(notesList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_notes_id.setText(rs.getString("notes_id"));
								JTF_subject_id.setText(rs.getString("subject_id"));
								JTF_course_id.setText(rs.getString("course_id"));
								JTF_notes_write.setText(rs.getString("notes_write"));
								JTF_dateofclass.setText(rs.getString("dateofclass"));
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}
					}
				});		
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {

							int a=JOptionPane.showConfirmDialog(pn,"Are you sure do you want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New notes_write:");
								JTF_notes_write.setText(pack);
								String query="update notes set notes_write='"+pack+"' where notes_id="+JTF_notes_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadnotes();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete5.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent aevt)
				{
					JB_delete=new JButton("Delete");
								
					JTF_notes_id.setText(null);
					JTF_subject_id.setText(null);
					JTF_course_id.setText(null);
					JTF_notes_write.setText(null);
					JTF_dateofclass.setText(null);
																
					pn.removeAll();
					jframe.invalidate();
					jframe.validate();
					jframe.repaint();
								
					pn1=new JPanel();
					pn1.setLayout(new GridLayout(10,10));
					pn1.add(JL_notes_id);
					pn1.add(JTF_notes_id);
					pn1.add(JL_subject_id);
					pn1.add(JTF_subject_id);
					pn1.add(JL_course_id);
					pn1.add(JTF_course_id);
					pn1.add(JL_notes_write);
					pn1.add(JTF_notes_write);
					pn1.add(JL_dateofclass);
					pn1.add(JTF_dateofclass);
																
					pn3=new JPanel(new FlowLayout());
					pn3.add(JB_delete);
					pn1.setBounds(115,80,300,250);
					pn3.setBounds(200,350,75,35);
								 
					pn2=new JPanel(new FlowLayout());
					notesList=new List(10);
					loadnotes();
					pn2.add(notesList);
					pn2.setBounds(250,350,300,180);
					
					pn.add(pn1);
					pn.add(pn3);
					pn.add(pn2);
								
					pn.setLayout(new BorderLayout());
					jframe.add(pn);
					jframe.setSize(800,800);
					jframe.validate();
					
					notesList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent ievt) 
						{
							try 
							{
								rs=stmt.executeQuery("select * from notes");
								while (rs.next()) 
								{													
									if (rs.getString("notes_id").equals(notesList.getSelectedItem()));
												break;
								}
								if (!rs.isAfterLast()) 
								{
									JTF_notes_id.setText(rs.getString("notes_id"));
									JTF_subject_id.setText(rs.getString("subject_id"));
									JTF_course_id.setText(rs.getString("course_id"));
									JTF_notes_write.setText(rs.getString("notes_write"));
									JTF_dateofclass.setText(rs.getString("dateofclass"));							}
							}
							catch (SQLException selectException) 
							{
									displaySQLErrors(selectException);
							}
						}
					});	
					JB_delete.addActionListener(new ActionListener() {
					 @Override
					 public void actionPerformed(ActionEvent e) 
					 { 
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure do you want to delete:");
							if(a==JOptionPane.YES_OPTION)
							 {  
								 
								 String query="DELETE FROM notes WHERE notes_id="+JTF_course_id.getText();
							     int i=stmt.executeUpdate(query);
								 JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								 loadnotes();
							 }
						 }
						 catch(SQLException exp)
						 {
							 displaySQLErrors(exp);
						 }
						}
					});
				}
			});
			view5.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						pn.removeAll();
						jframe.invalidate();
						jframe.validate();
						jframe.repaint();
								
						
						JLabel view=new JLabel("notes View");
						JB_view=new JButton("View");
						Font myFont = new Font("Serif",Font.BOLD,50);
						view.setFont((myFont));
						
						pn1=new JPanel();
						pn2=new JPanel();
						pn1.add(view);
						pn2.add(JB_view);
						pn.add(pn1);
						pn.add(pn2);
						pn.setLayout(new FlowLayout());
								
						jframe.add(pn);
						jframe.setSize(800,800);
						jframe.validate();
								
				    	 JB_view.addActionListener(new ActionListener() {
							 @Override
							public void actionPerformed(ActionEvent e) 
							 { 
								JFrame jf=new JFrame("notes Details");     
							    JTable jt;       
							    DefaultTableModel model = new DefaultTableModel(); 
							    jt= new JTable(model); 
							    model.addColumn("notes Id");
							    model.addColumn("subject Id");
							    model.addColumn("course id");
							    model.addColumn("notes_write");
							    model.addColumn("dateofclass");	
							    try 
							    {
									rs=stmt.executeQuery("select * from notes");
									while(rs.next()) 
									{
										 model.addRow(new Object[]{rs.getString("notes_id"),rs.getString("subject_id"),rs.getString("course_id"),
												 rs.getString("notes_write"),rs.getString("dateofclass")});
									}
								}
								catch(SQLException exp) 
							    {
									displaySQLErrors(exp);
							    }
									
								jt.setEnabled(false);
						        jt.setBounds(30, 40, 180, 150); 
							    JScrollPane sp = new JScrollPane(jt);
							    jf.add(sp); 
							    jf.setSize(800, 400); 
							    jf.setVisible(true);        
						}   
					});	
				}
			});
		}
}
