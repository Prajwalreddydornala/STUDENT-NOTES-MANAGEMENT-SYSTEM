package SNMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class course
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_course_id,JL_course_name,JL_subject_id,JL_course_credits,JL_enrollment_year,JL_course_start_date,JL_course_end_date,JL_college_code,JL_student_id;
	private JTextField JTF_course_id,JTF_course_name,JTF_subject_id,JTF_course_credits,JTF_enrollment_year,JTF_course_start_date,JTF_course_end_date,JTF_college_code,JTF_student_id;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert4,update4,view4,delete4;
	private List courseList;
	private Choice subjectId,collegeCode,studentId;
	
	public course(JPanel pn,JFrame jframe,JMenuItem insert4,JMenuItem update4,JMenuItem view4,JMenuItem delete4)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert4=insert4;
		this.update4=update4;
		this.view4=view4;
		this.delete4=delete4;
		
		JL_course_id=new JLabel("course_id:");
		JTF_course_id=new JTextField(10);
		JL_course_name=new JLabel("course Name:");
		JTF_course_name=new JTextField(10);
		JL_subject_id=new JLabel("subject Id:");
		subjectId=new Choice();
        JTF_subject_id=new JTextField(10);
		JL_course_credits=new JLabel("course credits:");
        JTF_course_credits=new JTextField(10);
        JL_enrollment_year=new JLabel("Enrollment Year:");
        JTF_enrollment_year=new JTextField(10);
        JL_course_start_date=new JLabel("Start Date:");
        JTF_course_start_date=new JTextField(10);
        JL_course_end_date=new JLabel("End Date:");
        JTF_course_end_date=new JTextField(10);
        JL_college_code=new JLabel("college Code:");
        collegeCode=new Choice();
        JTF_college_code=new JTextField(10);
        JL_student_id=new JLabel("student Id:");
        studentId=new Choice();
        JTF_student_id=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737086","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadsubject()
	{
		try
		{
			//subjectId=new Choice();
			subjectId.removeAll();
			rs=stmt.executeQuery("select * from subject");
			while(rs.next()) 
			{
				subjectId.add(rs.getString("subject_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadcollege()
	{
		try
		{
			//collegeCode=new Choice();
			collegeCode.removeAll();
			rs=stmt.executeQuery("select * from college");
			while(rs.next()) 
			{
				collegeCode.add(rs.getString("college_code"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadstudent()
	{
		try
		{
			//studentId=new Choice();
			studentId.removeAll();
			rs=stmt.executeQuery("select * from student");
			while(rs.next()) 
			{
				studentId.add(rs.getString("student_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadcourse()
	{
		try
		{
			courseList=new List();
			courseList.removeAll();
			rs=stmt.executeQuery("select * from course");
			while(rs.next()) 
			{
				courseList.add(rs.getString("course_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				loadsubject();
				loadcollege();
				loadstudent();
				loadcourse();
				
				JTF_course_id.setText(null);
				JTF_course_name.setText(null);
				//JTF_subject_id.setText(null);
				JTF_course_credits.setText(null);
				JTF_enrollment_year.setText(null);
				JTF_course_start_date.setText(null);
				JTF_course_end_date.setText(null);
				//JTF_college_code.setText(null);
				//JTF_student_id.setText(null);
				
				loadcourse();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_course_id);
				pn1.add(JTF_course_id);
				pn1.add(JL_course_name);
				pn1.add(JTF_course_name);
				pn1.add(JL_subject_id);
				pn1.add(subjectId);
				pn1.add(JL_course_credits);
				pn1.add(JTF_course_credits);
				pn1.add(JL_enrollment_year);
				pn1.add(JTF_enrollment_year);
				pn1.add(JL_course_start_date);
				pn1.add(JTF_course_start_date);
				pn1.add(JL_course_end_date);
				pn1.add(JTF_course_end_date);
				pn1.add(JL_college_code);
				pn1.add(collegeCode);
				pn1.add(JL_student_id);
				pn1.add(studentId);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				courseList=new List(10);
				loadcourse();
				pn2.add(courseList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO course VALUES(" + JTF_course_id.getText() + ","
							+ "'" +JTF_course_name.getText() +"',"+"'"+subjectId.getSelectedItem()+"',"+JTF_course_credits.getText()+","+JTF_enrollment_year.getText()+","+JTF_course_start_date.getText()+","+JTF_course_end_date.getText()+","+"'"+collegeCode.getSelectedItem()+"',"+"'"+studentId.getSelectedItem()+"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadcourse();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_course_id.setText(null);
				JTF_course_name.setText(null);
				JTF_subject_id.setText(null);
				JTF_course_credits.setText(null);
				JTF_enrollment_year.setText(null);
				JTF_course_start_date.setText(null);
				JTF_course_end_date.setText(null);
				JTF_college_code.setText(null);
				JTF_student_id.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_course_id);
				pn1.add(JTF_course_id);
				pn1.add(JL_course_name);
				pn1.add(JTF_course_name);
				pn1.add(JL_subject_id);
				pn1.add(JTF_subject_id);
				pn1.add(JL_course_credits);
				pn1.add(JTF_course_credits);
				pn1.add(JL_enrollment_year);
				pn1.add(JTF_enrollment_year);
				pn1.add(JL_course_start_date);
				pn1.add(JTF_course_start_date);
				pn1.add(JL_course_end_date);
				pn1.add(JTF_course_end_date);
				pn1.add(JL_college_code);
				pn1.add(JTF_college_code);
				pn1.add(JL_student_id);
				pn1.add(JTF_student_id);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				courseList=new List(10);
				loadcourse();
				pn2.add(courseList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				courseList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from course");
							while (rs.next()) 
							{
								if (rs.getString("course_id").equals(courseList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_course_id.setText(rs.getString("course_id"));
								JTF_course_name.setText(rs.getString("course_name"));
								JTF_subject_id.setText(rs.getString("subject_id"));
								JTF_course_credits.setText(rs.getString("course_credits"));
								JTF_enrollment_year.setText(rs.getString("enrollment_year"));
								JTF_course_start_date.setText(rs.getString("course_start_date"));
								JTF_course_end_date.setText(rs.getString("course_end_date"));
								JTF_college_code.setText(rs.getString("college_code"));
								JTF_student_id.setText(rs.getString("student_id"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New course name:");
								JTF_course_name.setText(pack);
								String query="update course set course_name='"+pack+"' where course_id="+JTF_course_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadcourse();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_course_id.setText(null);
				JTF_course_name.setText(null);
				JTF_subject_id.setText(null);
				JTF_course_credits.setText(null);
				JTF_enrollment_year.setText(null);
				JTF_course_start_date.setText(null);
				JTF_course_end_date.setText(null);
				JTF_college_code.setText(null);
				JTF_student_id.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_course_id);
				pn1.add(JTF_course_id);
				pn1.add(JL_course_name);
				pn1.add(JTF_course_name);
				pn1.add(JL_subject_id);
				pn1.add(JTF_subject_id);
				pn1.add(JL_course_credits);
				pn1.add(JTF_course_credits);
				pn1.add(JL_enrollment_year);
				pn1.add(JTF_enrollment_year);
				pn1.add(JL_course_start_date);
				pn1.add(JTF_course_start_date);
				pn1.add(JL_course_end_date);
				pn1.add(JTF_course_end_date);
				pn1.add(JL_college_code);
				pn1.add(JTF_college_code);
				pn1.add(JL_student_id);
				pn1.add(JTF_student_id);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				courseList=new List(10);
				loadcourse();
				pn2.add(courseList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				courseList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from course");
							while (rs.next()) 
							{
								if (rs.getString("course_id").equals(courseList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_course_id.setText(rs.getString("course_id"));
								JTF_course_name.setText(rs.getString("course_name"));
								JTF_subject_id.setText(rs.getString("subject_id"));
								JTF_course_credits.setText(rs.getString("course_credits"));
								JTF_enrollment_year.setText(rs.getString("enrollment_year"));
								JTF_course_start_date.setText(rs.getString("course_start_date"));
								JTF_course_end_date.setText(rs.getString("course_end_date"));
								JTF_college_code.setText(rs.getString("college_code"));
								JTF_student_id.setText(rs.getString("student_id"));
								
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM course WHERE course_id="+courseList.getSelectedItem();
								String query="DELETE FROM course WHERE course_id="+JTF_course_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadcourse();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("course View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("course Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("course_id");
				        model.addColumn("course name");
				        model.addColumn("subject Id");
				        model.addColumn("course credits");
				        model.addColumn("Enrollment Year");
				        model.addColumn("Course Start Date");
				        model.addColumn("Course End Date");
				        model.addColumn("college Code");
				        model.addColumn("student Id");
					    try 
					    {		
							rs=stmt.executeQuery("select * from course");
							while(rs.next())
							{
								model.addRow(new Object[]{rs.getString("course_id"), 
										rs.getString("course_name"),rs.getString("subject_id"),rs.getString("course_credits"),rs.getString("enrollment_year")
										,rs.getString("course_start_date"),rs.getString("course_end_date"),rs.getString("college_code"),rs.getString("student_id")});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
