package SNMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class subject
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_subject_id,JL_subject_name,JL_teacher_contact,JL_teacher_name;
	private JTextField JTF_subject_id,JTF_subject_name,JTF_teacher_contact,JTF_teacher_name;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert3,update3,view3,delete3;
	private List subjectList;
	
	public subject(JPanel pn,JFrame jframe,JMenuItem insert3,JMenuItem update3,JMenuItem view3,JMenuItem delete3)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert3=insert3;
		this.update3=update3;
		this.view3=view3;
		this.delete3=delete3;
		
		JL_subject_id=new JLabel("subject_id:");
		JTF_subject_id=new JTextField(10);
		JL_subject_name=new JLabel("subject Name:");
		JTF_subject_name=new JTextField(10);
		JL_teacher_contact=new JLabel("teacher contact:");
        JTF_teacher_contact=new JTextField(10);
        JL_teacher_name=new JLabel("teacher name:");
        JTF_teacher_name=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737086","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadsubject()
	{
		try
		{
			subjectList=new List();
			subjectList.removeAll();
			rs=stmt.executeQuery("select * from subject");
			while(rs.next()) 
			{
				subjectList.add(rs.getString("subject_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				
				JTF_subject_id.setText(null);
				JTF_subject_name.setText(null);
				JTF_teacher_contact.setText(null);
				JTF_teacher_name.setText(null);
				
				loadsubject();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_subject_id);
				pn1.add(JTF_subject_id);
				pn1.add(JL_subject_name);
				pn1.add(JTF_subject_name);
				pn1.add(JL_teacher_contact);
				pn1.add(JTF_teacher_contact);
				pn1.add(JL_teacher_name);
				pn1.add(JTF_teacher_name);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				subjectList=new List(10);
				loadsubject();
				pn2.add(subjectList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO subject VALUES(" + JTF_subject_id.getText() + ","
							+ "'" +JTF_subject_name.getText() +"'," +"'"+JTF_teacher_contact.getText() +"'," + "'"+JTF_teacher_name.getText() +"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadsubject();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_subject_id.setText(null);
				JTF_subject_name.setText(null);
				JTF_teacher_contact.setText(null);
				JTF_teacher_name.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_subject_id);
				pn1.add(JTF_subject_id);
				pn1.add(JL_subject_name);
				pn1.add(JTF_subject_name);
				pn1.add(JL_teacher_contact);
				pn1.add(JTF_teacher_contact);
				pn1.add(JL_teacher_name);
				pn1.add(JTF_teacher_name);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				subjectList=new List(10);
				loadsubject();
				pn2.add(subjectList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				subjectList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from subject");
							while (rs.next()) 
							{
								if (rs.getString("subject_id").equals(subjectList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_subject_id.setText(rs.getString("subject_id"));
								JTF_subject_name.setText(rs.getString("subject_name"));
								JTF_teacher_contact.setText(rs.getString("teacher_contact"));
								JTF_teacher_name.setText(rs.getString("teacher_name"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New subject Name:");
								JTF_subject_name.setText(pack);
								String query="update subject set subject_name='"+pack+"' where subject_id="+JTF_subject_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadsubject();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_subject_id.setText(null);
				JTF_subject_name.setText(null);
				JTF_teacher_contact.setText(null);
				JTF_teacher_name.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_subject_id);
				pn1.add(JTF_subject_id);
				pn1.add(JL_subject_name);
				pn1.add(JTF_subject_name);
				pn1.add(JL_teacher_contact);
				pn1.add(JTF_teacher_contact);
				pn1.add(JL_teacher_name);
				pn1.add(JTF_teacher_name);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				subjectList=new List(10);
				loadsubject();
				pn2.add(subjectList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				subjectList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from subject");
							while (rs.next()) 
							{
								if (rs.getString("subject_id").equals(subjectList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_subject_id.setText(rs.getString("subject_id"));
								JTF_subject_name.setText(rs.getString("subject_name"));
								JTF_teacher_contact.setText(rs.getString("teacher_contact"));
								JTF_teacher_name.setText(rs.getString("teacher_name"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM subject WHERE subject_id="+subjectList.getSelectedItem();
								String query="DELETE FROM subject WHERE subject_id="+JTF_subject_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadsubject();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("subject View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("subject Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("subject_id");
				        model.addColumn("subject name");
				        model.addColumn("teacher contact");
				        model.addColumn("teacher name");
					    try 
					    {		
							rs=stmt.executeQuery("select * from subject");
							while(rs.next())
							{
								 model.addRow(new Object[]{rs.getInt(1), 
								 rs.getString(2),rs.getString(3),rs.getString(4)});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
