package SNMS;
import java.awt.*;
import javax.swing.*;
public class SNMSUI extends JFrame
{
	private JPanel Jpn0,Jpn1;
    private JMenuBar mbar;
    private JMenu college,student,subject,course,notes;
    private JMenuItem insert1,update1,view1,delete1;
    private JMenuItem insert2,update2,view2,delete2;
    private JMenuItem insert3,update3,view3,delete3;
    private JMenuItem insert4,update4,view4,delete4;
    private JMenuItem insert5,update5,view5,delete5;
    /*private JMenuItem insert6,update6,view6,delete6;
    private JMenuItem s1,s2,s3,s4,s5;*/

    private JLabel labelName;
    
    public void defineComponents()
    {
    	Jpn0=new JPanel();
    	Jpn1=new JPanel();
    	
    	mbar=new JMenuBar();
    	
    	//statesAvailable=new JMenu("List Of States Available");//d_1
    	college=new JMenu("college");
    	student=new JMenu("student");
    	subject=new JMenu("subject");
    	course=new JMenu("course");
    	notes=new JMenu("notes");
    	
    	labelName=new JLabel("Student Notes Management System"); 	
    }
    public void addComponents()
    {
    	add(Jpn0);
    	Jpn1.add(labelName);
    	Jpn1.setAlignmentY(CENTER_ALIGNMENT);
    	Jpn1.setBounds(500,500,800,100);
    	Jpn0.add(Jpn1);
    	
    	setJMenuBar(mbar);
    	
    	mbar.add(college);
    	mbar.add(student);
    	mbar.add(subject);
    	mbar.add(course);
    	mbar.add(notes);
    	


    	college.add(insert1=new JMenuItem("Insert"));
    	college.add(update1=new JMenuItem("Update"));
    	college.add(view1=new JMenuItem("View"));
    	college.add(delete1=new JMenuItem("Delete"));
    	
    	student.add(insert2=new JMenuItem("Insert"));
    	student.add(update2=new JMenuItem("Update"));
    	student.add(view2=new JMenuItem("View"));
    	student.add(delete2=new JMenuItem("Delete"));
    	
    	subject.add(insert3=new JMenuItem("Insert"));
    	subject.add(update3=new JMenuItem("Update"));
    	subject.add(view3=new JMenuItem("View"));
    	subject.add(delete3=new JMenuItem("Delete"));
    	
    	course.add(insert4=new JMenuItem("Insert"));
    	course.add(update4=new JMenuItem("Update"));
    	course.add(view4=new JMenuItem("View"));
    	course.add(delete4=new JMenuItem("Delete"));
    	
    	notes.add(insert5=new JMenuItem("Insert"));
    	notes.add(update5=new JMenuItem("Update"));
    	notes.add(view5=new JMenuItem("View"));
    	notes.add(delete5=new JMenuItem("Delete"));

    }
    public void registerComponents()
    {
    	college obj_college=new college(Jpn0,SNMSUI.this,insert1,update1,view1,delete1);
    	obj_college.buildGUI();
    	student obj_student=new student(Jpn0,SNMSUI.this,insert2,update2,view2,delete2);
    	obj_student.buildGUI();
    	subject obj_subject=new subject(Jpn0,SNMSUI.this,insert3,update3,view3,delete3);
    	obj_subject.buildGUI();
    	course obj_course=new course(Jpn0,SNMSUI.this,insert4,update4,view4,delete4);
    	obj_course.buildGUI();
    	notes obj_notes=new notes(Jpn0,SNMSUI.this,insert5,update5,view5,delete5);
    	obj_notes.buildGUI();
    }
	public SNMSUI()
	{
		defineComponents();
		addComponents();
		registerComponents();
		setSize(400,500);
		setBackground(Color.GRAY);
		setVisible(true);
		setTitle("STUDENT NOTES MANAGEMENT SYSTEM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
