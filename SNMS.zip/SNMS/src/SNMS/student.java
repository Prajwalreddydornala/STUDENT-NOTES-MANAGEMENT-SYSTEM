package SNMS;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;

public class student
{
	private JPanel pn,pn1,pn2,pn3;
	private JFrame jframe;
	private JButton JB_insert,JB_modify,JB_view,JB_delete;
	private JLabel JL_student_id,JL_student_name,JL_student_contact,JL_student_address,JL_college_code;
	private JTextField JTF_student_id,JTF_student_name,JTF_student_contact,JTF_student_address,JTF_college_code;
	Connection con;
	ResultSet rs;
	Statement stmt;
	private JMenuItem insert2,update2,view2,delete2;
	private List studentList;
	private Choice collegeCode;
	
	public student(JPanel pn,JFrame jframe,JMenuItem insert2,JMenuItem update2,JMenuItem view2,JMenuItem delete2)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectDatabase();
		
		this.jframe=jframe;
		this.insert2=insert2;
		this.update2=update2;
		this.view2=view2;
		this.delete2=delete2;
		
		JL_student_id=new JLabel("student_id:");
		JTF_student_id=new JTextField(10);
		JL_student_name=new JLabel("student Name:");
		JTF_student_name=new JTextField(10);
		JL_student_contact=new JLabel("student Contact:");
        JTF_student_contact=new JTextField(10);
        JL_student_address=new JLabel("student Address:");
        JTF_student_address=new JTextField(10);
        JL_college_code=new JLabel("college Code:");
        collegeCode=new Choice();
        JTF_college_code=new JTextField(10);

        this.pn=pn;
      
	}
	public void connectDatabase()
	{
		try 
		{
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","it19737086","vasavi");  
			  
			stmt=con.createStatement(); 
			stmt.executeUpdate("commit");
			
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadcollege()
	{
		try
		{
			//collegeCode=new Choice();
			collegeCode.removeAll();
			rs=stmt.executeQuery("select * from college");
			while(rs.next()) 
			{
				collegeCode.add(rs.getString("college_code"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void loadstudent()
	{
		try
		{
			studentList=new List();
			studentList.removeAll();
			rs=stmt.executeQuery("select * from student");
			while(rs.next()) 
			{
				studentList.add(rs.getString("student_id"));
			}
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public void buildGUI()
	{
		
		insert2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_insert=new JButton("Submit");
				loadcollege();
				
				JTF_student_id.setText(null);
				JTF_student_name.setText(null);
				JTF_student_contact.setText(null);
				JTF_student_address.setText(null);
				//JTF_college_code.setText(null);
				
				loadstudent();
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_student_id);
				pn1.add(JTF_student_id);
				pn1.add(JL_student_name);
				pn1.add(JTF_student_name);
				pn1.add(JL_student_contact);
				pn1.add(JTF_student_contact);
				pn1.add(JL_student_address);
				pn1.add(JTF_student_address);
				pn1.add(JL_college_code);
				pn1.add(collegeCode);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_insert);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				studentList=new List(10);
				loadstudent();
				pn2.add(studentList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_insert.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						try
						{
							String query= "INSERT INTO student VALUES(" + JTF_student_id.getText() + ","
							+ "'" +JTF_student_name.getText() +"'," +"'"+JTF_student_contact.getText() +"'," + "'"+JTF_student_address.getText() +"',"+"'"+collegeCode.getSelectedItem()+"')";
							int i = stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(pn,"\nInserted "+i+" rows successfully");
							loadstudent();
							System.out.println("Done");
						}
						catch(SQLException e) 
						{
							displaySQLErrors(e);
						}
					}
				});	
			}
		});
		update2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_modify=new JButton("Modify");
				
				JTF_student_id.setText(null);
				JTF_student_name.setText(null);
				JTF_student_contact.setText(null);
				JTF_student_address.setText(null);
				JTF_college_code.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_student_id);
				pn1.add(JTF_student_id);
				pn1.add(JL_student_name);
				pn1.add(JTF_student_name);
				pn1.add(JL_student_contact);
				pn1.add(JTF_student_contact);
				pn1.add(JL_student_address);
				pn1.add(JTF_student_address);
				pn1.add(JL_college_code);
				pn1.add(JTF_college_code);
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_modify);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				studentList=new List(10);
				loadstudent();
				pn2.add(studentList);
				pn2.setBounds(200,350,300,180);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				studentList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from student");
							while (rs.next()) 
							{
								if (rs.getString("student_id").equals(studentList.getSelectedItem()))
								break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_student_id.setText(rs.getString("student_id"));
								JTF_student_name.setText(rs.getString("student_name"));
								JTF_student_contact.setText(rs.getString("student_contact"));
								JTF_student_address.setText(rs.getString("student_address"));
								JTF_college_code.setText(rs.getString("college_code"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_modify.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to update:");
							if(a==JOptionPane.YES_OPTION)
							{  
								String pack=JOptionPane.showInputDialog(pn,"Enter New student Name:");
								JTF_student_name.setText(pack);
								String query="update student set student_name='"+pack+"' where student_id="+JTF_student_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nUpdated "+i+" rows succesfully");
								loadstudent();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
		delete2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				JB_delete=new JButton("Delete");
				
				JTF_student_id.setText(null);
				JTF_student_name.setText(null);
				JTF_student_contact.setText(null);
				JTF_student_address.setText(null);
				JTF_college_code.setText(null);
				
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				pn1=new JPanel();
				pn1.setLayout(new GridLayout(10,10));
				pn1.add(JL_student_id);
				pn1.add(JTF_student_id);
				pn1.add(JL_student_name);
				pn1.add(JTF_student_name);
				pn1.add(JL_student_contact);
				pn1.add(JTF_student_contact);
				pn1.add(JL_student_address);
				pn1.add(JTF_student_address);
				pn1.add(JL_college_code);
				pn1.add(JTF_college_code);
				
				
				pn3=new JPanel(new FlowLayout());
				pn3.add(JB_delete);
				pn1.setBounds(115,80,300,250);
				pn3.setBounds(200,350,75,35);
				 
				pn2=new JPanel(new FlowLayout());
				studentList=new List(10);
				loadstudent();
				pn2.add(studentList);
				pn2.setBounds(200,350,300,200);  
				
				pn.add(pn1);
				pn.add(pn3);
				pn.add(pn2);
				
				pn.setLayout(new BorderLayout());
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				studentList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt)
					{
						try 
						{
							rs=stmt.executeQuery("select * from student");
							while (rs.next()) 
							{
								if (rs.getString("student_id").equals(studentList.getSelectedItem()))
								 break;
							}
							if (!rs.isAfterLast()) 
							{
								JTF_student_id.setText(rs.getString("student_id"));
								JTF_student_name.setText(rs.getString("student_name"));
								JTF_student_contact.setText(rs.getString("student_contact"));
								JTF_student_address.setText(rs.getString("student_address"));
								JTF_college_code.setText(rs.getString("college_code"));
								
							}
						} 
						catch (SQLException selectException) 
						{
							displaySQLErrors(selectException);
						}	
					}
				});	
				JB_delete.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						 try 
						 {
							int a=JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
							if(a==JOptionPane.YES_OPTION)
							{  
								//String query="DELETE FROM student WHERE student_id="+studentList.getSelectedItem();
								String query="DELETE FROM student WHERE student_id="+JTF_student_id.getText();
								int i=stmt.executeUpdate(query);
								JOptionPane.showMessageDialog(pn,"\nDeleted "+i+" rows succesfully");
								loadstudent();
							}
						 }
						catch(SQLException e)
						{
							displaySQLErrors(e);
						}
					}
				});
			}
		});
 		view2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent aevt)
			{
				pn.removeAll();
				jframe.invalidate();
				jframe.validate();
				jframe.repaint();
				
				JLabel view=new JLabel("student View");
				JB_view=new JButton("View");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view.setFont((myFont));
				
				pn1=new JPanel();
				pn2=new JPanel();
				pn1.add(view);
				pn2.add(JB_view);
				pn.add(pn1);
				pn.add(pn2);
				pn.setBounds(500,800,300,300);
				pn.setLayout(new FlowLayout());
				
				jframe.add(pn);
				jframe.setSize(800,800);
				jframe.validate();
				
				JB_view.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent aevt)
					{
						JFrame jf=new JFrame("student Details");
						JTable jt;
						DefaultTableModel model = new DefaultTableModel(); 
				        jt = new JTable(model); 
				        model.addColumn("student_id");
				        model.addColumn("student name");
				        model.addColumn("student contact");
				        model.addColumn("student address");
				        model.addColumn("college Code");
					    try 
					    {		
							rs=stmt.executeQuery("select * from student");
							while(rs.next())
							{
								model.addRow(new Object[]{rs.getString("student_id"), 
										rs.getString("student_name"),rs.getString("student_contact"),rs.getString("student_address")
										,rs.getString("college_code")});
							}
						}
						catch(SQLException e) 
					    {
							displaySQLErrors(e);
						}
						jt.setEnabled(false);
				        jt.setBounds(30, 40, 300, 300); 
				        JScrollPane jsp = new JScrollPane(jt); 
				        jf.add(jsp); 
				        jf.setSize(800, 400); 
				        jf.setVisible(true); 
					}
				});	
			}
		});	
	}
}
